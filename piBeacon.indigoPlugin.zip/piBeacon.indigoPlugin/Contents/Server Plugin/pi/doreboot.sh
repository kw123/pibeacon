#!/bin/bash
sudo echo reboot >  /home/pi/pibeacon/temp/rebootNeeded