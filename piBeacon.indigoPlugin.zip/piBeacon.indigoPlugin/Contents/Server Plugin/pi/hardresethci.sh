#!/bin/bash
sudo rmmod btusb
sudo modprobe btusb
