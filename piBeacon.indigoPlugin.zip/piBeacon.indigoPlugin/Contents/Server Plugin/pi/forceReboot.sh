sudo killall -9 python3
sudo killall -9 python2
sudo killall -9 python
sudo sync
sleep 5
sudo reboot -f 
